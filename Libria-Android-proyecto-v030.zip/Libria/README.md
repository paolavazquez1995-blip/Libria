# Libria — Tu mundo entre páginas

Aplicación Android de biblioteca y lectura personal, sin anuncios ni suscripciones. Proyecto configurado para Android 7.0 o posterior (minSdk 24).

## Funciones incluidas
- Biblioteca local con importación de EPUB, PDF, TXT y Markdown.
- Selector de archivos de Android; permite elegir Google Drive si aparece como proveedor en el teléfono.
- Lectura de EPUB por capítulos (incluye imágenes incrustadas), PDF por páginas y TXT/Markdown.
- Progreso de lectura guardado en el dispositivo.
- Gestos táctiles y controles para avanzar/retroceder.
- Temas claro, sepia, oscuro y tema especial de gatitos.
- Ajustes de tipografía, tamaño e interlineado.
- Subrayados y notas en EPUB/TXT/Markdown; marcadores y exportación de anotaciones.
- Lectura en voz alta cuando el motor de voz de Android WebView está disponible.
- Exportación y restauración de copias de seguridad de la biblioteca.

## Compilar
Requisitos: Android Studio reciente, JDK 17 y Android SDK 35. Abrir la carpeta del proyecto y ejecutar `:app:assembleDebug`. El identificador de aplicación es `com.libria.reader`.

## Dependencias y observaciones
- Los motores JSZip y PDF.js se cargan desde CDN, por lo que la primera lectura de EPUB/PDF requiere conexión a internet.
- El subrayado integrado está disponible en EPUB/TXT/Markdown. Los PDF se muestran con PDF.js en canvas y no tienen todavía una capa de anotación de texto.
- La copia de seguridad puede incluir los archivos originales; su tamaño depende de los libros importados. Guárdala en un lugar seguro.
- El proyecto fuente no equivale a un APK instalado. Para generar el APK se necesita compilarlo con Android Studio/SDK.
